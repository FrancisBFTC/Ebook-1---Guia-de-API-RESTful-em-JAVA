package org.spring.halloween;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HalloweenApplication {

	public static void main(String[] args) {
		SpringApplication.run(HalloweenApplication.class, args);
	}

}
