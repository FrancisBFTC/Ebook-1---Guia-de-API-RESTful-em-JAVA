package org.spring.halloween2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Halloween2Application {

	public static void main(String[] args) {
		SpringApplication.run(Halloween2Application.class, args);
	}

}
